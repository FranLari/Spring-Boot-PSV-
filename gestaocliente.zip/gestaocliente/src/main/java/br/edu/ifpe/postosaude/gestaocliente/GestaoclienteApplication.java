package br.edu.ifpe.postosaude.gestaocliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoclienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaoclienteApplication.class, args);
	}

}
