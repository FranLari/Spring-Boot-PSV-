package br.edu.ifpe.postosaude.gestaocliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoclienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
